# Linha de Balanço Planejamento v0.2

Versão mais funcional do protótipo para GitHub/Vercel.

## Inclui

- Linha de balanço com arraste horizontal, resize, vínculos FS, toque longo, marcos verticais, zoom, linhas por lote-mãe e linha fixa por família.
- Cronograma com importação XLSX/CSV e tabela local.
- Compras com Kanban, importação XLSX e cálculo de cobertura por quantidade.
- Médio prazo com matriz semanal e pesos editáveis.
- Curto prazo com microserviços ponderados.
- Físico-financeiro demo.
- Supabase schema inicial.

## Rodar

```bash
npm install
cp .env.example .env
npm run dev
```

Funciona em modo demo/local. Supabase entra para persistir dados, versões e histórico.
