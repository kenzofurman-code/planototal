create extension if not exists "uuid-ossp";

create table if not exists projects (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  image_url text,
  address text,
  area numeric,
  status text default 'ativo',
  start_date date,
  planned_end_date date,
  created_at timestamptz default now()
);

create table if not exists schedule_versions (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid references projects(id) on delete cascade,
  name text not null,
  type text default 'active',
  version_number integer default 0,
  is_active boolean default false,
  is_baseline boolean default false,
  created_at timestamptz default now()
);

create table if not exists schedule_tasks (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid references projects(id) on delete cascade,
  version_id uuid references schedule_versions(id) on delete cascade,
  lot_mother text,
  lot text,
  package_name text,
  package_family text,
  start_date date not null,
  end_date date not null,
  progress_percent numeric default 0,
  quantity numeric,
  unit text,
  cost_estimated numeric,
  color text,
  updated_at timestamptz default now()
);

create table if not exists schedule_dependencies (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid references projects(id) on delete cascade,
  version_id uuid references schedule_versions(id) on delete cascade,
  from_task_id text,
  to_task_id text,
  type text default 'FS',
  lag_days integer default 0
);

create table if not exists line_balance_settings (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid references projects(id) on delete cascade,
  version_id uuid references schedule_versions(id) on delete cascade,
  project_start_date date,
  group_line_count jsonb default '{}'::jsonb,
  package_family_lane_map jsonb default '{}'::jsonb
);

create table if not exists procurement_cards (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid references projects(id) on delete cascade,
  item_code text,
  item_description text not null,
  required_quantity numeric default 0,
  requested_quantity numeric default 0,
  ordered_quantity numeric default 0,
  contracted_quantity numeric default 0,
  delivered_quantity numeric default 0,
  coverage_percent numeric default 0,
  current_stage text default 'A programar',
  real_status text default 'Pendente'
);

create table if not exists medium_plan_tasks (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid references projects(id) on delete cascade,
  lot_path jsonb default '[]'::jsonb,
  package_name text,
  weight_within_parent numeric default 100,
  progress_percent numeric default 0
);

create table if not exists microservice_items (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid references projects(id) on delete cascade,
  package_family text not null,
  name text not null,
  weight_percent numeric not null,
  measured_percent numeric default 0
);

create table if not exists change_log (
  id uuid primary key default uuid_generate_v4(),
  project_id uuid references projects(id) on delete cascade,
  module text not null,
  entity_type text not null,
  entity_id text,
  field text,
  old_value jsonb,
  new_value jsonb,
  changed_at timestamptz default now(),
  source text default 'user'
);
