import React, { useEffect, useMemo, useRef, useState } from 'react';
import ReactDOM from 'react-dom/client';
import * as XLSX from 'xlsx';
import { BarChart3, Building2, CalendarRange, CheckSquare, FileSpreadsheet, Home, KanbanSquare, LineChart, Menu, Settings } from 'lucide-react';
import { dependencies as initialDependencies, procurement as initialProcurement, projects, tasks as demoTasks } from './demoData';
import { addDays, diffDays, excelDateToIso, parseDate, toIsoDate } from './lib/date';
import { isSupabaseConfigured } from './lib/supabase';
import type { Dependency, Page, ProcurementCard, Project, Task } from './types';
import './styles.css';

const projectStart = parseDate('2025-08-01');
const chartEnd = parseDate('2026-12-01');
const zoomPx: Record<number, number> = { 1: 2.2, 2: 3.2, 3: 4.8, 4: 7.2, 5: 10.5 };
const headerH = 92;
const laneH = 26;

function loadLocal<T>(key: string, fallback: T): T { try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback; } catch { return fallback; } }
function norm(s: string) { return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, ''); }
function getCell(row: Record<string, unknown>, aliases: string[]) {
  const keys = Object.keys(row);
  for (const alias of aliases) {
    const found = keys.find(k => norm(k) === norm(alias) || norm(k).includes(norm(alias)));
    if (found) return row[found];
  }
}

function App() {
  const [collapsed, setCollapsed] = useState(true);
  const [page, setPage] = useState<Page>('projects');
  const [project, setProject] = useState<Project>(projects[0]);
  const [tasks, setTasks] = useState<Task[]>(() => loadLocal('lb_tasks_v02', demoTasks));
  const [dependencies, setDependencies] = useState<Dependency[]>(() => loadLocal('lb_deps_v02', initialDependencies));
  const [procurement, setProcurement] = useState<ProcurementCard[]>(() => loadLocal('lb_proc_v02', initialProcurement));
  useEffect(() => localStorage.setItem('lb_tasks_v02', JSON.stringify(tasks)), [tasks]);
  useEffect(() => localStorage.setItem('lb_deps_v02', JSON.stringify(dependencies)), [dependencies]);
  useEffect(() => localStorage.setItem('lb_proc_v02', JSON.stringify(procurement)), [procurement]);

  const menu: Array<{ key: Page; label: string; icon: React.ReactNode }> = [
    { key:'projects', label:'Projetos', icon:<Home/> }, { key:'dashboard', label:'Dashboard', icon:<BarChart3/> }, { key:'schedule', label:'Cronograma', icon:<FileSpreadsheet/> },
    { key:'line', label:'Linha de balanço', icon:<Building2/> }, { key:'procurement', label:'Compras', icon:<KanbanSquare/> }, { key:'medium', label:'Médio prazo', icon:<CalendarRange/> },
    { key:'short', label:'Curto prazo', icon:<CheckSquare/> }, { key:'financial', label:'Físico-financeiro', icon:<LineChart/> }, { key:'settings', label:'Configurações', icon:<Settings/> }
  ];

  return <div className="app">
    <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <button className="menu-button" onClick={() => setCollapsed(!collapsed)}><Menu /></button>
      {menu.map(item => <button key={item.key} className={page === item.key ? 'active' : ''} onClick={() => setPage(item.key)} title={item.label}>{item.icon}{!collapsed && <span>{item.label}</span>}</button>)}
    </aside>
    <main>
      <header className="topbar"><div><strong>{project.name}</strong><span>{project.address}</span></div><b className="pill">{isSupabaseConfigured ? 'Supabase conectado' : 'Modo demo local'}</b></header>
      {page === 'projects' && <Projects selected={project} onSelect={(p) => { setProject(p); setPage('dashboard'); }} />}
      {page === 'dashboard' && <Dashboard tasks={tasks} procurement={procurement} />}
      {page === 'schedule' && <Schedule tasks={tasks} setTasks={setTasks} />}
      {page === 'line' && <LineBalance tasks={tasks} setTasks={setTasks} dependencies={dependencies} setDependencies={setDependencies} />}
      {page === 'procurement' && <Procurement cards={procurement} setCards={setProcurement} />}
      {page === 'medium' && <MediumPlan />}
      {page === 'short' && <ShortTerm />}
      {page === 'financial' && <Financial tasks={tasks} />}
      {page === 'settings' && <SettingsPage />}
    </main>
  </div>;
}

function PageHeader({ title, subtitle, children }: { title: string; subtitle: string; children?: React.ReactNode }) {
  return <div className="page-header"><div><h1>{title}</h1><p>{subtitle}</p></div><div className="actions">{children}</div></div>;
}
function Metric({ label, value }: { label: string; value: string }) { return <div className="metric"><span>{label}</span><strong>{value}</strong></div>; }

function Projects({ selected, onSelect }: { selected: Project; onSelect: (p: Project) => void }) {
  return <section className="page"><PageHeader title="Projetos" subtitle="Selecione uma obra para abrir o planejamento integrado."><button className="primary">Novo projeto</button></PageHeader>
    <div className="project-grid">{projects.map(p => <article className={`project-card ${selected.id === p.id ? 'selected' : ''}`} key={p.id}><img src={p.imageUrl}/><div><span className="pill">{p.status}</span><h2>{p.name}</h2><p>{p.address}</p><small>{p.area.toLocaleString('pt-BR')} m² · {p.startDate} até {p.plannedEndDate}</small><button onClick={() => onSelect(p)}>Selecionar</button></div></article>)}</div></section>;
}

function Dashboard({ tasks, procurement }: { tasks: Task[]; procurement: ProcurementCard[] }) {
  const progress = tasks.length ? tasks.reduce((sum, t) => sum + t.progress, 0) / tasks.length : 0;
  return <section className="page"><PageHeader title="Dashboard" subtitle="Resumo executivo da obra." />
    <div className="metric-grid"><Metric label="Avanço médio" value={`${progress.toFixed(1)}%`} /><Metric label="Atividades longo prazo" value={String(tasks.length)} /><Metric label="Compras pendentes" value={String(procurement.filter(p => p.coverage < 100).length)} /><Metric label="Alvenaria curto prazo" value="60%" /></div>
    <div className="card flow">Longo prazo → Médio prazo → Curto prazo → Medição → Retroalimentação</div></section>;
}

function Schedule({ tasks, setTasks }: { tasks: Task[]; setTasks: (tasks: Task[]) => void }) {
  const [versionName, setVersionName] = useState('V01 - Replanejamento local');
  async function readFile(file: File) {
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { cellDates: true });
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets[workbook.SheetNames[0]]);
    const imported = rows.map((row, index) => {
      const start = excelDateToIso(getCell(row, ['inicio','data inicio','start','início']));
      const end = excelDateToIso(getCell(row, ['fim','termino','término','data fim','end']));
      if (!start || !end) return undefined;
      const name = String(getCell(row, ['pacote','atividade','servico','serviço']) ?? `Atividade ${index + 1}`);
      return { id:`imp-${Date.now()}-${index}`, lotMother:String(getCell(row, ['lote_mae','lote mãe','grupo']) ?? 'GERAL'), lot:String(getCell(row, ['lote','local','pavimento']) ?? `Lote ${index + 1}`), packageName:name, packageFamily:String(getCell(row, ['familia','família','macroatividade','macro']) ?? name), startDate:start, endDate:end, progress:Number(getCell(row, ['progresso','avanço','avanco']) ?? 0), color:'#4f46e5', quantity:Number(getCell(row, ['quantidade','qtd']) ?? 0) || undefined, unit:String(getCell(row, ['unidade','un']) ?? '') || undefined, cost:Number(getCell(row, ['custo','valor','custo_estimado']) ?? 0) || undefined } as Task;
    }).filter(Boolean) as Task[];
    if (!imported.length) return alert(`Arquivo lido, mas não encontrei colunas mínimas de início/fim. Abas: ${workbook.SheetNames.join(', ')}`);
    setTasks(imported); setVersionName(`Importado: ${file.name}`);
  }
  return <section className="page"><PageHeader title="Cronograma / Importação / Versões" subtitle="Importação, tabela e linha de base."><label className="file-button">Importar XLSX/CSV<input type="file" accept=".xlsx,.xls,.csv" onChange={e => e.target.files?.[0] && readFile(e.target.files[0])}/></label><button onClick={() => setVersionName(`Cópia local ${new Date().toLocaleTimeString('pt-BR')}`)}>Criar cópia</button><button onClick={() => {setTasks(demoTasks); setVersionName('Demo restaurado')}}>Restaurar demo</button></PageHeader>
    <div className="card table-wrap"><div className="table-title"><strong>{versionName}</strong><span>{tasks.length} atividades</span></div><table><thead><tr><th>Lote-mãe</th><th>Lote</th><th>Pacote</th><th>Família</th><th>Início</th><th>Fim</th><th>Avanço</th></tr></thead><tbody>{tasks.map(t => <tr key={t.id}><td>{t.lotMother}</td><td>{t.lot}</td><td>{t.packageName}</td><td>{t.packageFamily}</td><td>{t.startDate}</td><td>{t.endDate}</td><td>{t.progress}%</td></tr>)}</tbody></table></div></section>;
}

type Drag = { mode:'pending'|'move'|'resize'|'link'; id:string; startClientX:number; startClientY:number; startSvgX:number; startSvgY:number; start:string; end:string; targetId?:string };

function LineBalance({ tasks, setTasks, dependencies, setDependencies }: { tasks: Task[]; setTasks: (tasks: Task[]) => void; dependencies: Dependency[]; setDependencies: (deps: Dependency[]) => void }) {
  const [zoom, setZoom] = useState(3);
  const [groupLines, setGroupLines] = useState<Record<string, number>>(() => loadLocal('lb_group_lines_v02', { 'TORRE-PAVIMENTOS': 3, FACHADA: 3 }));
  const [familyLane, setFamilyLane] = useState<Record<string, number>>(() => loadLocal('lb_family_lane_v02', { ESTRUTURA:1, ALVENARIA:1, INSTALAÇÕES:2, REVESTIMENTO:3, PINTURA:3, FACHADA:2, ESQUADRIAS:3 }));
  const [showDeps, setShowDeps] = useState(true);
  const [drag, setDrag] = useState<Drag | null>(null);
  const [linkPoint, setLinkPoint] = useState<{x:number;y:number} | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const longPressRef = useRef<number | null>(null);
  useEffect(() => localStorage.setItem('lb_group_lines_v02', JSON.stringify(groupLines)), [groupLines]);
  useEffect(() => localStorage.setItem('lb_family_lane_v02', JSON.stringify(familyLane)), [familyLane]);

  const groups = Array.from(new Set(tasks.map(t => t.lotMother)));
  const families = Array.from(new Set(tasks.map(t => t.packageFamily)));
  const rows = useMemo(() => {
    const out: Array<{type:'group'|'lot'; key:string; label:string; tasks:Task[]; height:number; group?:string; y:number}> = [];
    let y = headerH;
    for (const g of groups) {
      out.push({ type:'group', key:g, label:g, tasks:[], height:30, y }); y += 30;
      for (const lot of Array.from(new Set(tasks.filter(t => t.lotMother === g).map(t => t.lot)))) {
        const height = 12 + (groupLines[g] ?? 3) * laneH;
        out.push({ type:'lot', key:`${g}-${lot}`, label:lot, tasks:tasks.filter(t => t.lotMother === g && t.lot === lot), height, group:g, y }); y += height;
      }
    }
    return out;
  }, [tasks, groupLines, groups]);
  const width = Math.max(1300, diffDays(projectStart, chartEnd) * zoomPx[zoom] + 160);
  const height = headerH + rows.reduce((s,r) => s + r.height, 0) + 40;
  const xFor = (d: Date) => diffDays(projectStart, d) * zoomPx[zoom];
  const pointer = (e: React.PointerEvent) => { const r = svgRef.current?.getBoundingClientRect(); return {x:e.clientX-(r?.left??0), y:e.clientY-(r?.top??0)}; };
  const positions = new Map<string, {x:number;y:number;w:number;h:number}>();
  rows.forEach(row => { if (row.type === 'lot') row.tasks.forEach(t => { const lane = Math.min(groupLines[row.group ?? ''] ?? 3, familyLane[t.packageFamily] ?? 1); const x = xFor(parseDate(t.startDate)); const w = Math.max(10, (diffDays(parseDate(t.startDate), parseDate(t.endDate)) + 1) * zoomPx[zoom]); positions.set(t.id, {x, y: row.y + 8 + (lane - 1) * laneH, w, h:18}); }); });
  const clearLong = () => { if (longPressRef.current) { window.clearTimeout(longPressRef.current); longPressRef.current = null; } };
  const updateTask = (id:string, patch:Partial<Task>) => setTasks(tasks.map(t => t.id === id ? {...t, ...patch} : t));
  const closestTask = (pt:{x:number;y:number}, except:string) => { let best: string|undefined, dist=Infinity; positions.forEach((b,id) => { if(id===except) return; if(pt.x>=b.x-16&&pt.x<=b.x+b.w+16&&pt.y>=b.y-16&&pt.y<=b.y+b.h+16){ const d=Math.hypot(pt.x-(b.x+b.w/2), pt.y-(b.y+b.h/2)); if(d<dist){best=id;dist=d;} } }); return best; };
  function startBar(e: React.PointerEvent, t: Task){ e.preventDefault(); try{e.currentTarget.setPointerCapture(e.pointerId)}catch{}; const pt=pointer(e); const d: Drag={id:t.id, mode:'pending', startClientX:e.clientX, startClientY:e.clientY, startSvgX:pt.x, startSvgY:pt.y, start:t.startDate, end:t.endDate}; setDrag(d); clearLong(); longPressRef.current=window.setTimeout(()=>{setDrag({...d, mode:'link'}); setLinkPoint({x:pt.x+40,y:pt.y}); if(navigator.vibrate) navigator.vibrate(35);},520); }
  function startResize(e: React.PointerEvent, t: Task){ e.preventDefault(); e.stopPropagation(); try{e.currentTarget.setPointerCapture(e.pointerId)}catch{}; const pt=pointer(e); clearLong(); setDrag({id:t.id, mode:'resize', startClientX:e.clientX, startClientY:e.clientY, startSvgX:pt.x, startSvgY:pt.y, start:t.startDate, end:t.endDate}); }
  function onMove(e: React.PointerEvent){ if(!drag) return; const task=tasks.find(t=>t.id===drag.id); if(!task) return; const pt=pointer(e), dx=e.clientX-drag.startClientX, dy=e.clientY-drag.startClientY; if(drag.mode==='pending'){ if(Math.abs(dx)>7||Math.abs(dy)>7) clearLong(); if(Math.abs(dx)>6&&Math.abs(dx)>=Math.abs(dy)){ setDrag({...drag, mode:'move'}); return; } if(Math.abs(dy)>16&&Math.abs(dy)>Math.abs(dx)){ setDrag({...drag, mode:'link'}); setLinkPoint(pt); return; } } if(drag.mode==='move'){ const delta=Math.round((pt.x-drag.startSvgX)/zoomPx[zoom]); const dur=diffDays(parseDate(drag.start), parseDate(drag.end)); const ns=addDays(parseDate(drag.start), delta); updateTask(task.id, {startDate:toIsoDate(ns), endDate:toIsoDate(addDays(ns,dur))}); } if(drag.mode==='resize'){ const ne=addDays(projectStart, Math.round(pt.x/zoomPx[zoom])); if(ne>=parseDate(task.startDate)) updateTask(task.id, {endDate:toIsoDate(ne)}); } if(drag.mode==='link'){ const targetId=closestTask(pt, drag.id); setDrag({...drag, targetId}); setLinkPoint(pt); } }
  function onUp(){ clearLong(); if(drag?.mode==='link'&&drag.targetId&&drag.targetId!==drag.id&&!dependencies.some(d=>d.fromTaskId===drag.id&&d.toTaskId===drag.targetId)) setDependencies([...dependencies, {id:`dep-${Date.now()}`, fromTaskId:drag.id, toTaskId:drag.targetId, type:'FS'}]); setDrag(null); setLinkPoint(null); }

  return <section className="page"><PageHeader title="Linha de balanço" subtitle="Visualização com drag, resize, vínculos FS, marcos, zoom e linhas fixas."><button onClick={() => setTasks(demoTasks)}>Restaurar demo</button></PageHeader>
  <div className="line-shell"><aside className="settings-panel"><h3>Configurações</h3><label>Zoom<input type="range" min={1} max={5} value={zoom} onChange={e=>setZoom(Number(e.target.value))}/></label><label className="inline"><input type="checkbox" checked={showDeps} onChange={e=>setShowDeps(e.target.checked)}/> mostrar dependências</label><h4>Linhas por lote-mãe</h4>{groups.map(g=><label key={g}>{g}<select value={groupLines[g]??3} onChange={e=>setGroupLines({...groupLines,[g]:Number(e.target.value)})}><option value={1}>1 linha</option><option value={2}>2 linhas</option><option value={3}>3 linhas</option><option value={4}>4 linhas</option></select></label>)}<h4>Linha por família</h4>{families.map(f=><label key={f}>{f}<select value={familyLane[f]??1} onChange={e=>setFamilyLane({...familyLane,[f]:Number(e.target.value)})}><option value={1}>Linha 1</option><option value={2}>Linha 2</option><option value={3}>Linha 3</option><option value={4}>Linha 4</option></select></label>)}<p className="hint">Tablet: toque e segure uma barra para criar vínculo FS. Desktop: arraste verticalmente ou segure.</p></aside>
  <div className="chart-scroll">{drag?.mode==='link'&&<div className="link-banner">Modo vínculo: solte sobre a sucessora</div>}<svg ref={svgRef} width={width} height={height} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp} onContextMenu={e=>e.preventDefault()}>
    <rect x={0} y={0} width={width} height={headerH} fill="#fafafa"/><line x1={0} x2={width} y1={headerH} y2={headerH} stroke="#cbd5e1"/>
    {Array.from({length:75}).map((_,i)=>{ const d=addDays(projectStart,i*7), x=xFor(d), show=zoom>=4||i%(zoom===3?2:4)===0; return <g key={i}><line x1={x} x2={x} y1={headerH} y2={height} stroke="#e5e7eb"/>{show&&<text x={x+4} y={zoom>=4?54:68} fontSize={11} fill="#64748b">{zoom>=4?`S${i+1} · `:''}{d.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'})}</text>}</g>; })}
    {Array.from({length:18}).map((_,i)=>{ const d=new Date(projectStart.getFullYear(), projectStart.getMonth()+i, 1), x=xFor(d); return <g key={i}><line x1={x} x2={x} y1={0} y2={height} stroke="#cbd5e1"/><text x={x+4} y={23} fontSize={13} fontWeight={700} fill="#374151">{d.toLocaleDateString('pt-BR',{month:'short'}).replace('.','').toUpperCase()}/{String(d.getFullYear()).slice(-2)} - M{i+1}</text></g>; })}
    {[['2025-09-01','INÍCIO'],['2026-01-12','ACAB.'],['2026-06-10','ESQ.']].map(([date,label])=>{const x=xFor(parseDate(date)); return <g key={date}><line x1={x} x2={x} y1={headerH} y2={height} stroke="#b91c1c" strokeDasharray="4 4"/><text x={x+8} y={150} transform={`rotate(-90 ${x+8} 150)`} fontSize={11} fontWeight={700} fill="#b91c1c">{label}</text></g>;})}
    {showDeps&&dependencies.map(d=>{const a=positions.get(d.fromTaskId), b=positions.get(d.toTaskId); if(!a||!b) return null; const sx=a.x+a.w, sy=a.y+a.h/2, ex=b.x, ey=b.y+b.h/2, mx=Math.max(sx+25,(sx+ex)/2); return <path key={d.id} d={`M ${sx} ${sy} C ${mx} ${sy}, ${mx} ${ey}, ${ex} ${ey}`} fill="none" stroke="#64748b" strokeWidth={1.4}/>;})}
    {drag?.mode==='link'&&linkPoint&&positions.get(drag.id)&&(()=>{const a=positions.get(drag.id)!; return <path d={`M ${a.x+a.w} ${a.y+a.h/2} C ${a.x+a.w+40} ${a.y+a.h/2}, ${linkPoint.x-40} ${linkPoint.y}, ${linkPoint.x} ${linkPoint.y}`} fill="none" stroke="#16a34a" strokeWidth={2.2} strokeDasharray="6 4"/>;})()}
    {rows.map(row=> row.type==='group' ? <g key={row.key}><rect x={0} y={row.y} width={width} height={row.height} fill="#eef2ff"/><text x={10} y={row.y+20} fontSize={12} fontWeight={700}>{row.label}</text></g> : <g key={row.key}><rect x={0} y={row.y} width={width} height={row.height} fill="#fff"/><line x1={0} x2={width} y1={row.y+row.height} y2={row.y+row.height} stroke="#e5e7eb"/><text x={10} y={row.y+20} fontSize={12}>{row.label}</text>{row.tasks.map(t=>{const p=positions.get(t.id)!; const isTarget=drag?.mode==='link'&&drag.targetId===t.id; return <g key={t.id}><rect x={p.x} y={p.y} width={p.w} height={p.h} rx={4} fill={t.color} stroke={isTarget?'#22c55e':'#fff'} strokeWidth={isTarget?3:1} onPointerDown={e=>startBar(e,t)}/><rect x={p.x+p.w-10} y={p.y} width={10} height={p.h} rx={2} fill="#fff" opacity={0.25} onPointerDown={e=>startResize(e,t)}/><text x={p.x+5} y={p.y+13} fontSize={10} fontWeight={700} fill="#fff">{t.packageName}</text><rect x={p.x} y={p.y+14} width={p.w*t.progress/100} height={4} fill="#fff" opacity={0.55}/><title>{t.packageName} | {t.lot} | {t.startDate} a {t.endDate}</title></g>})}</g>)}
  </svg></div></div></section>;
}

function Procurement({ cards, setCards }: { cards: ProcurementCard[]; setCards: (cards: ProcurementCard[]) => void }) {
  async function readFile(file: File) {
    const buffer = await file.arrayBuffer(); const workbook = XLSX.read(buffer, { cellDates:true }); const rows:Record<string,unknown>[]=[]; workbook.SheetNames.forEach(sheet=>XLSX.utils.sheet_to_json<Record<string,unknown>>(workbook.Sheets[sheet]).forEach(row=>rows.push({...row,__sheet:sheet})));
    const grouped = new Map<string, ProcurementCard>();
    rows.forEach((row, i) => { const code=String(getCell(row,['cod item','cód item','codigo item','código item','item'])??`ITEM-${i}`); const item=String(getCell(row,['descricao','descrição','insumo','item'])??code); const sheet=String(row.__sheet??'').toLowerCase(); const qty=Number(getCell(row,['qtde solicitada','quantidade','qtde convertida','qtd'])??0)||0; const card=grouped.get(code)??{id:`imp-${code}`,stage:'A solicitar',status:'Pendente',item,code,required:Math.max(qty,1),requested:0,ordered:0,contracted:0,delivered:0,unit:String(getCell(row,['unidade','un'])??''),coverage:0}; if(sheet.includes('pedido')) card.ordered+=qty; else card.requested+=qty; if(String(getCell(row,['contrato','cod contrato','cód contrato'])??'')) card.contracted+=qty; grouped.set(code,card); });
    const imported=Array.from(grouped.values()).map(c=>{const covered=Math.max(c.requested,c.ordered,c.contracted,c.delivered); const coverage=c.required?Math.min(100,Math.round(covered/c.required*100)):0; return {...c,coverage,stage:c.contracted?'Contrato emitido':c.ordered?'Pedido emitido':c.requested?'Solicitado':'A solicitar',status:coverage>=100?'Completo':coverage>0?'Parcial':'Pendente'};});
    if(imported.length) setCards(imported); else alert(`Arquivo lido, mas não consegui consolidar itens. Abas: ${workbook.SheetNames.join(', ')}`);
  }
  const stages=['A solicitar','Solicitado','Pedido emitido','Contrato emitido','Entregue'];
  return <section className="page"><PageHeader title="Compras" subtitle="Kanban com cobertura por quantidade e etapa do processo."><label className="file-button">Importar requisições<input type="file" accept=".xlsx,.xls,.csv" onChange={e=>e.target.files?.[0]&&readFile(e.target.files[0])}/></label><button onClick={()=>setCards(initialProcurement)}>Restaurar demo</button></PageHeader><div className="kanban">{stages.map(stage=><div className="kanban-col" key={stage}><h3>{stage}</h3>{cards.filter(p=>p.stage===stage).map(p=><article className={`buy-card ${p.coverage<100?'warning':'ok'}`} key={p.id}><strong>{p.item}</strong><span>{p.code}</span><div className="bar"><i style={{width:`${p.coverage}%`}}/></div><small>Cobertura {p.coverage}% · solicitado {p.requested} · pedido {p.ordered}/{p.required} {p.unit}</small><small>Contratado {p.contracted} · Entregue {p.delivered}</small><b>{p.status}</b></article>)}</div>)}</div></section>;
}

function MediumPlan() {
  const weeks=['S1','S2','S3','S4','S5','S6','S7','S8','S9','S10','S11','S12'];
  const [weights,setWeights]=useState([30,40,30]); const total=weights.reduce((a,b)=>a+b,0);
  return <section className="page"><PageHeader title="Médio prazo" subtitle="Abertura de lotes, ponderação e matriz semanal."/><div className="card"><strong className={total===100?'ok-text':'warn-text'}>Soma dos pesos: {total}%</strong></div><div className="card table-wrap"><table><thead><tr><th>Lote aberto</th><th>Peso</th>{weeks.map(w=><th key={w}>{w}</th>)}</tr></thead><tbody>{['Balancim 1','Balancim 2','Balancim 3'].map((lot,i)=><tr key={lot}><td>FACHADA / Fachada A / {lot}</td><td><input className="small-input" type="number" value={weights[i]} onChange={e=>setWeights(weights.map((w,idx)=>idx===i?Number(e.target.value):w))}/>%</td>{weeks.map((w,wi)=><td key={w}>{wi>=i&&wi<=i+3?<span className="tag">{['BAL','EMB','IMP','TEX'][wi-i]}</span>:null}</td>)}</tr>)}</tbody></table></div></section>;
}
function ShortTerm(){ const [marking,setMarking]=useState(100), [wall,setWall]=useState(50); const progress=marking*.2+wall*.8; return <section className="page"><PageHeader title="Curto prazo" subtitle="Microserviços ponderados e medição."/><div className="metric-grid"><div className="metric"><span>Marcação 20%</span><input type="range" min={0} max={100} value={marking} onChange={e=>setMarking(Number(e.target.value))}/><strong>{marking}%</strong></div><div className="metric"><span>Elevação 80%</span><input type="range" min={0} max={100} value={wall} onChange={e=>setWall(Number(e.target.value))}/><strong>{wall}%</strong></div><Metric label="Pacote consolidado" value={`${progress.toFixed(1)}%`}/></div></section>; }
function Financial({tasks}:{tasks:Task[]}){ const total=tasks.reduce((s,t)=>s+(t.cost??0),0), done=tasks.reduce((s,t)=>s+(t.cost??0)*t.progress/100,0); return <section className="page"><PageHeader title="Físico-financeiro" subtitle="Avanço físico x valor."/><div className="metric-grid"><Metric label="Valor vinculado demo" value={total.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}/><Metric label="Valor realizado demo" value={done.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}/></div></section>; }
function SettingsPage(){ return <section className="page"><PageHeader title="Configurações" subtitle="Parâmetros do sistema."/><div className="card"><p>Supabase: <strong>{isSupabaseConfigured?'configurado':'não configurado / modo demo'}</strong></p><p>Próximas configurações: data zero, calendário, feriados, famílias de pacote, tolerância de compras e templates de microserviços.</p></div></section>; }

ReactDOM.createRoot(document.getElementById('root')!).render(<App/>);
