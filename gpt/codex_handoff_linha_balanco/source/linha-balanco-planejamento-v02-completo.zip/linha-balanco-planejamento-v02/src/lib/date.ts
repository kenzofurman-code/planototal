export function parseDate(value: string): Date { return new Date(`${value}T00:00:00`); }
export function addDays(date: Date, days: number): Date { const d = new Date(date); d.setDate(d.getDate() + days); return d; }
export function diffDays(a: Date, b: Date): number { return Math.round((b.getTime() - a.getTime()) / 86400000); }
export function toIsoDate(date: Date): string { return date.toISOString().slice(0, 10); }
export function excelDateToIso(value: unknown): string | undefined {
  if (value instanceof Date) return toIsoDate(value);
  if (typeof value === 'number') return toIsoDate(new Date(Math.round((value - 25569) * 86400 * 1000)));
  if (typeof value === 'string') {
    const clean = value.trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(clean)) return clean.slice(0, 10);
    const parts = clean.split(/[\/\-]/).map(Number);
    if (parts.length === 3 && parts[2] > 1900) return `${parts[2]}-${String(parts[1]).padStart(2,'0')}-${String(parts[0]).padStart(2,'0')}`;
  }
  return undefined;
}
