# v0.2

Esta versão porta as últimas funções do visualizador para React e começa módulos além da casca.

## Pendente
- Persistência no Supabase.
- Change log real.
- Versionamento real V00/V01/V02.
- Regras completas de compras com abas específicas do ERP.
